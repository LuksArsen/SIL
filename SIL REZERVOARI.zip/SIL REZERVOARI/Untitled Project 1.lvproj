﻿<?xml version='1.0' encoding='UTF-8'?>
<Project Type="Project" LVVersion="14008000">
	<Property Name="SMProvider.SMVersion" Type="Int">201310</Property>
	<Property Name="varPersistentID:{08090629-F1F3-4D90-9D0C-A00161992E55}" Type="Ref">/My Computer/Untitled Library 1.lvlib/e</Property>
	<Property Name="varPersistentID:{0EA3A41E-F31A-40F4-8023-0326FEE50FDB}" Type="Ref">/My Computer/Untitled Library 1.lvlib/Ki</Property>
	<Property Name="varPersistentID:{4572DC80-5A9B-4390-9D71-25F2D6BC68E6}" Type="Ref">/My Computer/Untitled Library 1.lvlib/a1</Property>
	<Property Name="varPersistentID:{76DDBCB6-4D83-4F33-B3DA-935021D0E4E4}" Type="Ref">/My Computer/Untitled Library 1.lvlib/Kd</Property>
	<Property Name="varPersistentID:{78016E2E-E737-40AF-884C-A56774CED112}" Type="Ref">/My Computer/Untitled Library 1.lvlib/h2</Property>
	<Property Name="varPersistentID:{98A5AC2F-4574-4987-BAA5-EB4A00B95655}" Type="Ref">/My Computer/Untitled Library 1.lvlib/sys_run1</Property>
	<Property Name="varPersistentID:{9C6D9021-1BD6-4504-B3BF-3B903C66A9AE}" Type="Ref">/My Computer/Untitled Library 1.lvlib/h1</Property>
	<Property Name="varPersistentID:{B7002EA1-1F2B-4C17-85E7-8710F016D078}" Type="Ref">/My Computer/Untitled Library 1.lvlib/setPointH2</Property>
	<Property Name="varPersistentID:{C37B633A-8015-4CFA-BA9E-40C323FCE46C}" Type="Ref">/My Computer/Untitled Library 1.lvlib/L</Property>
	<Property Name="varPersistentID:{C6D229C8-7F0F-40C2-96D9-F9A05ACE5309}" Type="Ref">/My Computer/Untitled Library 1.lvlib/a3</Property>
	<Property Name="varPersistentID:{CB268B2F-1C97-4256-9AEE-3573FC803B1C}" Type="Ref">/My Computer/Untitled Library 1.lvlib/qP1</Property>
	<Property Name="varPersistentID:{D69A43F1-73AE-4B4A-A9C0-1297B475295B}" Type="Ref">/My Computer/Untitled Library 1.lvlib/setPointH1</Property>
	<Property Name="varPersistentID:{E6D97B4B-420D-48B4-824A-FFB3D13C27AD}" Type="Ref">/My Computer/Untitled Library 1.lvlib/h3</Property>
	<Property Name="varPersistentID:{EACE0CB9-CCB2-43B6-AFED-90B9B8D3710D}" Type="Ref">/My Computer/Untitled Library 1.lvlib/Kp</Property>
	<Property Name="varPersistentID:{FB7F4A1F-45BD-4660-925C-779E52337297}" Type="Ref">/My Computer/Untitled Library 1.lvlib/a2</Property>
	<Item Name="My Computer" Type="My Computer">
		<Property Name="IOScan.Faults" Type="Str"></Property>
		<Property Name="IOScan.NetVarPeriod" Type="UInt">100</Property>
		<Property Name="IOScan.NetWatchdogEnabled" Type="Bool">false</Property>
		<Property Name="IOScan.Period" Type="UInt">10000</Property>
		<Property Name="IOScan.PowerupMode" Type="UInt">0</Property>
		<Property Name="IOScan.Priority" Type="UInt">9</Property>
		<Property Name="IOScan.ReportModeConflict" Type="Bool">true</Property>
		<Property Name="IOScan.StartEngineOnDeploy" Type="Bool">false</Property>
		<Property Name="server.app.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.control.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.tcp.enabled" Type="Bool">false</Property>
		<Property Name="server.tcp.port" Type="Int">0</Property>
		<Property Name="server.tcp.serviceName" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.tcp.serviceName.default" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.vi.callsEnabled" Type="Bool">true</Property>
		<Property Name="server.vi.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="specify.custom.address" Type="Bool">false</Property>
		<Item Name="model.vi" Type="VI" URL="../model.vi"/>
		<Item Name="pid.vi" Type="VI" URL="../pid.vi"/>
		<Item Name="racunanje_pp.vi" Type="VI" URL="../racunanje_pp.vi"/>
		<Item Name="scada.vi" Type="VI" URL="../scada.vi"/>
		<Item Name="Untitled Library 1.lvlib" Type="Library" URL="../Untitled Library 1.lvlib"/>
		<Item Name="Dependencies" Type="Dependencies">
			<Item Name="vi.lib" Type="Folder">
				<Item Name="Clear Errors.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/error.llb/Clear Errors.vi"/>
				<Item Name="NILVSim.dll" Type="Document" URL="/&lt;vilib&gt;/Simulation/Implementation/shared/NILVSim.dll"/>
				<Item Name="SIM limit type.ctl" Type="VI" URL="/&lt;vilib&gt;/Simulation/Implementation/Shared/SIM limit type.ctl"/>
			</Item>
		</Item>
		<Item Name="Build Specifications" Type="Build"/>
	</Item>
</Project>
